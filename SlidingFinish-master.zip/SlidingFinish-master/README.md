SlidingFinish
=============
An Android library that help you to build app with swipe back gesture

# ScreenShot
![](https://github.com/xiaanming/SlidingFinish/blob/master/SlidingFinish/demo.gif)
