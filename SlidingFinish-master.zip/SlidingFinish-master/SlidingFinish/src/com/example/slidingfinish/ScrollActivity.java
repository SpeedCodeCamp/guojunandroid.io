package com.example.slidingfinish;

import android.os.Bundle;

public class ScrollActivity extends SwipeBackActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_scroll);
	}

}
